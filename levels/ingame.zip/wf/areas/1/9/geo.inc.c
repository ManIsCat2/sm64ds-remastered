// 0x0E000890
const GeoLayout wf_geo_000890[] = {
    GEO_CULLING_RADIUS(1000),
    GEO_OPEN_NODE(),
        GEO_DISPLAY_LIST(LAYER_OPAQUE, wf_seg7_dl_07007518),
    GEO_CLOSE_NODE(),
    GEO_END(),
};
