// 0x0E0009B8
const GeoLayout wf_geo_0009B8[] = {
    GEO_CULLING_RADIUS(1100),
    GEO_OPEN_NODE(),
        GEO_DISPLAY_LIST(LAYER_OPAQUE, wf_seg7_dl_0700BF50),
    GEO_CLOSE_NODE(),
    GEO_END(),
};
