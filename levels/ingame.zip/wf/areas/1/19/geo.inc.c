// 0x0E0009E8
const GeoLayout wf_geo_0009E8[] = {
    GEO_CULLING_RADIUS(2700),
    GEO_OPEN_NODE(),
        GEO_DISPLAY_LIST(LAYER_OPAQUE, wf_seg7_dl_0700D300),
    GEO_CLOSE_NODE(),
    GEO_END(),
};
