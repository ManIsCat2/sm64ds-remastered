// 0x0E0008E8
const GeoLayout wf_geo_0008E8[] = {
    GEO_CULLING_RADIUS(400),
    GEO_OPEN_NODE(),
        GEO_DISPLAY_LIST(LAYER_OPAQUE, wf_seg7_dl_07009278),
    GEO_CLOSE_NODE(),
    GEO_END(),
};
