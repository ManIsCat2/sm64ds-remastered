// 0x0E000860
const GeoLayout wf_geo_000860[] = {
    GEO_CULLING_RADIUS(1400),
    GEO_OPEN_NODE(),
        GEO_DISPLAY_LIST(LAYER_OPAQUE, wf_seg7_dl_07006820),
    GEO_CLOSE_NODE(),
    GEO_END(),
};
