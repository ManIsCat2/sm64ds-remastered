// 0x0E000940
const GeoLayout wf_geo_000940[] = {
    GEO_CULLING_RADIUS(800),
    GEO_OPEN_NODE(),
        GEO_DISPLAY_LIST(LAYER_OPAQUE, wf_seg7_dl_07009DB0),
    GEO_CLOSE_NODE(),
    GEO_END(),
};
