// 0x0E0009A0
const GeoLayout wf_geo_0009A0[] = {
    GEO_CULLING_RADIUS(3000),
    GEO_OPEN_NODE(),
        GEO_DISPLAY_LIST(LAYER_OPAQUE, wf_seg7_dl_0700BA28),
    GEO_CLOSE_NODE(),
    GEO_END(),
};
