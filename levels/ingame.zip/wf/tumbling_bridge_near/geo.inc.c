// 0x0E000AB0
const GeoLayout wf_geo_000AB0[] = {
    GEO_CULLING_RADIUS(400),
    GEO_OPEN_NODE(),
        GEO_DISPLAY_LIST(LAYER_OPAQUE, wf_seg7_dl_0700E0F0),
    GEO_CLOSE_NODE(),
    GEO_END(),
};
