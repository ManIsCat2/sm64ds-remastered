extern const GeoLayout small_bomp_geo[];
extern u8 small_bomp_n_renga04_ci4[];
extern u8 small_bomp_n_renga04_pal_rgba16[];
extern Vtx small_bomp_world_root_node_mesh_layer_1_vtx_0[22];
extern Gfx small_bomp_world_root_node_mesh_layer_1_tri_0[];
extern Gfx mat_small_bomp_renga04_f3d_v5[];
extern Gfx mat_revert_small_bomp_renga04_f3d_v5[];
extern Gfx small_bomp_world_root_node_mesh_layer_1[];
