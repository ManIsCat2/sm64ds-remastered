// 0x0E000440
const GeoLayout bob_geo_000440[] = {
    GEO_CULLING_RADIUS(1000),
    GEO_OPEN_NODE(),
        GEO_DISPLAY_LIST(LAYER_ALPHA, bob_seg7_dl_0700E458),
    GEO_CLOSE_NODE(),
    GEO_END(),
};
