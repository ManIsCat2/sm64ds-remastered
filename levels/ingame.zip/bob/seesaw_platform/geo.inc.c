const GeoLayout bob_seesaw_platform[] = {
	GEO_CULLING_RADIUS(1200),
	GEO_OPEN_NODE(),
		GEO_DISPLAY_LIST(LAYER_OPAQUE, seesaw_platform_000_displaylist_mesh_layer_1),
	GEO_CLOSE_NODE(),
	GEO_END(),
};
