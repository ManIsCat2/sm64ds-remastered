extern const Collision collision_bob[];
