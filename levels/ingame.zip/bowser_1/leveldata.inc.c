#include "levels/bowser_1/area_1/collision.inc.c"
#include "levels/bowser_1/area_1/macro.inc.c"
#include "levels/bowser_1/area_1/spline.inc.c"
#include "levels/bowser_1/model.inc.c"
