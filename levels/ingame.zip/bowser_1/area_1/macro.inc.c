const MacroObject bowser_1_area_1_macro_objs[] = {
	MACRO_OBJECT_END(),
};

