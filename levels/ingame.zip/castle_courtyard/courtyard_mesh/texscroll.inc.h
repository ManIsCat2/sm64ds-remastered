extern void scroll_courtyard_mesh_Visual_Model_mesh_layer_5_vtx_2();
extern void scroll_castle_courtyard_level_geo_courtyard_mesh();
