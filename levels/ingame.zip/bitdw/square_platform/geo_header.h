extern const GeoLayout geo_bitdw_000558[];
extern u8 square_platform_dai_ci8[];
extern u8 square_platform_dai_pal_rgba16[];
extern Vtx square_platform_world_root_node_mesh_layer_1_vtx_0[23];
extern Gfx square_platform_world_root_node_mesh_layer_1_tri_0[];
extern Gfx mat_square_platform_mat_kabe1_f3d[];
extern Gfx mat_revert_square_platform_mat_kabe1_f3d[];
extern Gfx square_platform_world_root_node_mesh_layer_1[];
