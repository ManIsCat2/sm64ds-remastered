extern const GeoLayout geo_bitdw_000528[];
extern u8 sliding_platform_yuka_ci4[];
extern u8 sliding_platform_yuka_pal_rgba16[];
extern Vtx sliding_platform_world_root_node_mesh_layer_1_vtx_0[24];
extern Gfx sliding_platform_world_root_node_mesh_layer_1_tri_0[];
extern Gfx mat_sliding_platform_mat_yuka_ue_f3d[];
extern Gfx mat_revert_sliding_platform_mat_yuka_ue_f3d[];
extern Gfx sliding_platform_world_root_node_mesh_layer_1[];
