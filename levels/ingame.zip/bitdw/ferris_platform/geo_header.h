extern const GeoLayout geo_bitdw_000588[];
extern u8 ferris_platform_saka_rgba16[];
extern Vtx ferris_platform_000_displaylist_mesh_layer_1_vtx_0[24];
extern Gfx ferris_platform_000_displaylist_mesh_layer_1_tri_0[];
extern Gfx mat_ferris_platform_mat_saka_f3d[];
extern Gfx mat_revert_ferris_platform_mat_saka_f3d[];
extern Gfx ferris_platform_000_displaylist_mesh_layer_1[];
