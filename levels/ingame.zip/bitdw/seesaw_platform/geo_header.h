extern const GeoLayout geo_bitdw_000540[];
extern u8 seesaw_platform_siso_rgba16[];
extern Vtx seesaw_platform_world_root_node_mesh_layer_1_vtx_0[24];
extern Gfx seesaw_platform_world_root_node_mesh_layer_1_tri_0[];
extern Gfx mat_seesaw_platform_mat_siso_001_f3d[];
extern Gfx mat_revert_seesaw_platform_mat_siso_001_f3d[];
extern Gfx seesaw_platform_world_root_node_mesh_layer_1[];
