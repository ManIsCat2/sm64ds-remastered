extern const GeoLayout geo_bitdw_000570[];
extern Lights1 ferris_wheel_axle_obj_buriki_f3d_lights;
extern u8 ferris_wheel_axle_tetuwaku_rgba16[];
extern Vtx ferris_wheel_axle_000_displaylist_mesh_layer_1_vtx_0[48];
extern Gfx ferris_wheel_axle_000_displaylist_mesh_layer_1_tri_0[];
extern Gfx mat_ferris_wheel_axle_obj_buriki_f3d[];
extern Gfx ferris_wheel_axle_000_displaylist_mesh_layer_1[];
