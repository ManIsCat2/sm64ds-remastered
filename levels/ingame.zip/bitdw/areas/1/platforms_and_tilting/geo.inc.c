// 0x0E000498
const GeoLayout geo_bitdw_000498[] = {
    GEO_CULLING_RADIUS(2400),
    GEO_OPEN_NODE(),
        GEO_DISPLAY_LIST(LAYER_OPAQUE, bitdw_seg7_dl_07007AA8),
    GEO_CLOSE_NODE(),
    GEO_END(),
};
