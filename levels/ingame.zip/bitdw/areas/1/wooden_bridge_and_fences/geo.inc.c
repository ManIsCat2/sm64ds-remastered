// 0x0E0003F0
const GeoLayout geo_bitdw_0003F0[] = {
    GEO_CULLING_RADIUS(2000),
    GEO_OPEN_NODE(),
        GEO_DISPLAY_LIST(LAYER_ALPHA, bitdw_seg7_dl_07003608),
    GEO_CLOSE_NODE(),
    GEO_END(),
};
