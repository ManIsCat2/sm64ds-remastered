// 0x0E0004C8
const GeoLayout geo_bitdw_0004C8[] = {
    GEO_CULLING_RADIUS(300),
    GEO_OPEN_NODE(),
        GEO_DISPLAY_LIST(LAYER_TRANSPARENT, bitdw_seg7_dl_070093B0),
    GEO_CLOSE_NODE(),
    GEO_END(),
};
