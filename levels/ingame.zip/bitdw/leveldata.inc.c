#include "levels/bitdw/area_1/collision.inc.c"
#include "levels/bitdw/area_1/macro.inc.c"
#include "levels/bitdw/area_1/spline.inc.c"
#include "levels/bitdw/model.inc.c"
