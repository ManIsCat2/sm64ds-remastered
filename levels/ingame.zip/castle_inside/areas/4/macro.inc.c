// 0x07077764 - 0x070777DE
const MacroObject rec_room_macro_objs[] = {
    MACRO_OBJECT_END(),
};
