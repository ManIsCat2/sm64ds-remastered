extern u8 castle_jrb_room_part2_geo_renga_rgba16[];
extern Vtx castle_jrb_room_part2_geo__19__castle_jrb_room_part2_geo_mesh_vtx_cull[8];
extern Vtx castle_jrb_room_part2_geo__19__castle_jrb_room_part2_geo_mesh_vtx_0[114];
extern Gfx castle_jrb_room_part2_geo__19__castle_jrb_room_part2_geo_mesh_tri_0[];
extern Gfx mat_castle_jrb_room_part2_geo_mat_renga_a_7_f3d[];
extern Gfx mat_revert_castle_jrb_room_part2_geo_mat_renga_a_7_f3d[];
extern Gfx castle_jrb_room_part2_geo[];
