extern u8 castle_bob_room_signs_geo_kanban_rgba16[];
extern Vtx castle_bob_room_signs_geo__14__castle_bob_room_signs_geo_mesh_vtx_cull[8];
extern Vtx castle_bob_room_signs_geo__14__castle_bob_room_signs_geo_mesh_vtx_0[8];
extern Gfx castle_bob_room_signs_geo__14__castle_bob_room_signs_geo_mesh_tri_0[];
extern Gfx mat_castle_bob_room_signs_geo_mat_kanban_f3d[];
extern Gfx mat_revert_castle_bob_room_signs_geo_mat_kanban_f3d[];
extern Gfx castle_bob_room_signs_geo[];
