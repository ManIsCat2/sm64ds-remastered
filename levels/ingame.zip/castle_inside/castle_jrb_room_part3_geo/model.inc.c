Gfx castle_jrb_room_part3_geo_sky_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 castle_jrb_room_part3_geo_sky_rgba16[] = {
	0x19, 0x75, 0x19, 0x75, 0x19, 0x75, 0x19, 0x75, 
	0x19, 0x75, 0x19, 0x75, 0x19, 0x75, 0x19, 0x75, 
	0x19, 0x75, 0x19, 0x75, 0x19, 0x75, 0x19, 0x75, 
	0x19, 0x75, 0x19, 0x75, 0x19, 0x75, 0x19, 0x75, 
	0x19, 0x75, 0x19, 0x75, 0x19, 0x75, 0x19, 0x75, 
	0x19, 0x75, 0x19, 0x75, 0x19, 0x75, 0x19, 0x75, 
	0x19, 0x75, 0x19, 0x75, 0x19, 0x75, 0x19, 0x75, 
	0x19, 0x75, 0x19, 0x75, 0x19, 0x75, 0x19, 0x75, 
	0x19, 0x75, 0x19, 0x75, 0x19, 0x75, 0x19, 0x75, 
	0x19, 0x75, 0x19, 0x75, 0x19, 0x75, 0x19, 0x75, 
	0x19, 0x75, 0x19, 0x75, 0x19, 0x75, 0x19, 0x75, 
	0x19, 0x75, 0x19, 0x75, 0x19, 0x75, 0x19, 0x75, 
	0x19, 0x75, 0x19, 0x75, 0x19, 0x75, 0x19, 0x75, 
	0x19, 0x75, 0x19, 0x75, 0x19, 0x75, 0x19, 0x75, 
	0x19, 0x75, 0x19, 0x75, 0x19, 0x75, 0x19, 0x75, 
	0x19, 0x75, 0x19, 0x75, 0x19, 0x75, 0x19, 0x75, 
	
};

Vtx castle_jrb_room_part3_geo__20__castle_jrb_room_part3_geo_mesh_vtx_cull[8] = {
	{{ {1229, 1229, -1741}, 0, {0, 0}, {0, 0, 0, 0} }},
	{{ {1229, 1229, 1280}, 0, {0, 0}, {0, 0, 0, 0} }},
	{{ {1229, 1639, 1280}, 0, {0, 0}, {0, 0, 0, 0} }},
	{{ {1229, 1639, -1741}, 0, {0, 0}, {0, 0, 0, 0} }},
	{{ {4301, 1229, -1741}, 0, {0, 0}, {0, 0, 0, 0} }},
	{{ {4301, 1229, 1280}, 0, {0, 0}, {0, 0, 0, 0} }},
	{{ {4301, 1639, 1280}, 0, {0, 0}, {0, 0, 0, 0} }},
	{{ {4301, 1639, -1741}, 0, {0, 0}, {0, 0, 0, 0} }},
};

Vtx castle_jrb_room_part3_geo__20__castle_jrb_room_part3_geo_mesh_vtx_0[16] = {
	{{ {4301, 1229, -717}, 0, {294, 694}, {96, 96, 96, 255} }},
	{{ {3065, 1639, -1229}, 0, {254, 510}, {184, 184, 184, 255} }},
	{{ {3277, 1229, -1741}, 0, {202, 538}, {96, 96, 96, 255} }},
	{{ {3789, 1639, -505}, 0, {318, 622}, {184, 184, 184, 255} }},
	{{ {4301, 1229, 256}, 0, {388, 700}, {96, 96, 96, 255} }},
	{{ {3789, 1639, 44}, 0, {372, 624}, {184, 184, 184, 255} }},
	{{ {3065, 1639, 768}, 0, {450, 522}, {184, 184, 184, 255} }},
	{{ {3277, 1229, 1280}, 0, {498, 556}, {96, 96, 96, 255} }},
	{{ {2253, 1229, 1280}, 0, {506, 406}, {96, 96, 96, 255} }},
	{{ {2465, 1639, 768}, 0, {454, 434}, {184, 184, 184, 255} }},
	{{ {1229, 1229, 256}, 0, {416, 250}, {96, 96, 96, 255} }},
	{{ {1741, 1639, 44}, 0, {390, 324}, {184, 184, 184, 255} }},
	{{ {1229, 1229, -717}, 0, {320, 244}, {96, 96, 96, 255} }},
	{{ {1741, 1639, -505}, 0, {336, 320}, {184, 184, 184, 255} }},
	{{ {2253, 1229, -1741}, 0, {212, 388}, {96, 96, 96, 255} }},
	{{ {2465, 1639, -1229}, 0, {260, 422}, {184, 184, 184, 255} }},
};

Gfx castle_jrb_room_part3_geo__20__castle_jrb_room_part3_geo_mesh_tri_0[] = {
	gsSPVertex(castle_jrb_room_part3_geo__20__castle_jrb_room_part3_geo_mesh_vtx_0 + 0, 16, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(3, 0, 4, 0, 3, 4, 5, 0),
	gsSP2Triangles(6, 5, 4, 0, 4, 7, 6, 0),
	gsSP2Triangles(8, 6, 7, 0, 6, 8, 9, 0),
	gsSP2Triangles(10, 9, 8, 0, 9, 10, 11, 0),
	gsSP2Triangles(12, 11, 10, 0, 11, 12, 13, 0),
	gsSP2Triangles(14, 13, 12, 0, 13, 14, 15, 0),
	gsSP2Triangles(2, 15, 14, 0, 15, 2, 1, 0),
	gsSP2Triangles(1, 11, 15, 0, 11, 1, 3, 0),
	gsSP2Triangles(11, 3, 5, 0, 5, 6, 11, 0),
	gsSP2Triangles(9, 11, 6, 0, 13, 15, 11, 0),
	gsSPEndDisplayList(),
};

Gfx mat_castle_jrb_room_part3_geo_mat_sky_7_f3d[] = {
	gsSPGeometryMode(G_LIGHTING, 0),
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, ENVIRONMENT, 0, SHADE, 0, TEXEL0, 0, SHADE, 0, ENVIRONMENT, 0, SHADE, 0),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 1, castle_jrb_room_part3_geo_sky_rgba16),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 0, 0, 7, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadBlock(7, 0, 0, 63, 1024),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b, 2, 0, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 3, 0, G_TX_WRAP | G_TX_NOMIRROR, 3, 0),
	gsDPSetTileSize(0, 0, 0, 28, 28),
	gsSPEndDisplayList(),
};

Gfx mat_revert_castle_jrb_room_part3_geo_mat_sky_7_f3d[] = {
	gsSPGeometryMode(0, G_LIGHTING),
	gsDPPipeSync(),
	gsSPEndDisplayList(),
};

Gfx castle_jrb_room_part3_geo[] = {
	gsSPClearGeometryMode(G_LIGHTING),
	gsSPVertex(castle_jrb_room_part3_geo__20__castle_jrb_room_part3_geo_mesh_vtx_cull + 0, 8, 0),
	gsSPSetGeometryMode(G_LIGHTING),
	gsSPCullDisplayList(0, 7),
	gsSPDisplayList(mat_castle_jrb_room_part3_geo_mat_sky_7_f3d),
	gsSPDisplayList(castle_jrb_room_part3_geo__20__castle_jrb_room_part3_geo_mesh_tri_0),
	gsSPDisplayList(mat_revert_castle_jrb_room_part3_geo_mat_sky_7_f3d),
	gsDPPipeSync(),
	gsSPSetGeometryMode(G_LIGHTING),
	gsSPClearGeometryMode(G_TEXTURE_GEN),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT, 0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT),
	gsSPTexture(65535, 65535, 0, 0, 0),
	gsSPEndDisplayList(),
};

