extern u8 castle_wf_room_sign_geo_kanban_rgba16[];
extern Vtx castle_wf_room_sign_geo__17__castle_wf_room_sign_geo_mesh_vtx_cull[8];
extern Vtx castle_wf_room_sign_geo__17__castle_wf_room_sign_geo_mesh_vtx_0[4];
extern Gfx castle_wf_room_sign_geo__17__castle_wf_room_sign_geo_mesh_tri_0[];
extern Gfx mat_castle_wf_room_sign_geo_mat_kanban_f3d[];
extern Gfx mat_revert_castle_wf_room_sign_geo_mat_kanban_f3d[];
extern Gfx castle_wf_room_sign_geo[];
