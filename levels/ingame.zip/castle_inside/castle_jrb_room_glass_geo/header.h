extern u8 castle_jrb_room_glass_geo_taiyo_rgba16[];
extern Vtx castle_jrb_room_glass_geo_vtx_cull[8];
extern Vtx castle_jrb_room_glass_geo_vtx_0[16];
extern Gfx castle_jrb_room_glass_geo_tri_0[];
extern Gfx mat_castle_jrb_room_glass_geo_mat_glass_f3d[];
extern Gfx mat_revert_castle_jrb_room_glass_geo_mat_glass_f3d[];
extern Gfx castle_jrb_room_glass_geo[];
