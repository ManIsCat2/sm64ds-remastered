// 0x07010D08 - 0x07010DB4
const MacroObject castle_grounds_area_1_macro_objs[] = {
	MACRO_OBJECT_WITH_BEH_PARAM(macro_wooden_signpost, 0, -1638, -788, 5540, DIALOG_167),
	MACRO_OBJECT_WITH_BEH_PARAM(macro_wooden_signpost, 90, -4710, -776, 3277, DIALOG_051),
	MACRO_OBJECT_WITH_BEH_PARAM(macro_wooden_signpost, 90, 1855, -935, 4581, DIALOG_065),
	MACRO_OBJECT_WITH_BEH_PARAM(macro_wooden_signpost, -90, 5427, -637, 1741, DIALOG_050),
    MACRO_OBJECT_END(),
};
