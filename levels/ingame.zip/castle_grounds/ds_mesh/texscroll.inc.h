extern void scroll_ds_mesh_Castle_Grounds_mesh_layer_5_vtx_0();
extern void scroll_castle_grounds_level_geo_ds_mesh();
